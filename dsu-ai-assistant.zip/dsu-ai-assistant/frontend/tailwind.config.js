/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // Deep navy / midnight blue - primary
        midnight: {
          50: "#eef1f8",
          100: "#d6ddef",
          200: "#aebadf",
          300: "#7f8fc6",
          400: "#4f5fa3",
          500: "#2f3d7a",
          600: "#212c5c",
          700: "#161d42",
          800: "#0e1330",
          900: "#080b1f",
          950: "#050713",
        },
        // Royal blue - secondary
        royal: {
          50: "#eef3ff",
          100: "#dbe6fe",
          200: "#b9cffe",
          300: "#8bb0fc",
          400: "#5786f8",
          500: "#3462ef",
          600: "#2445d6",
          700: "#2038ab",
          800: "#1f3288",
          900: "#1e2f6c",
        },
        // Electric cyan - accent
        cyan: {
          50: "#ecfeff",
          100: "#cffafe",
          200: "#a4f4fd",
          300: "#67e9fa",
          400: "#2ad4ec",
          500: "#0fb6cf",
          600: "#0a90ac",
          700: "#0d738b",
          800: "#125d71",
          900: "#144d5f",
        },
      },
      fontFamily: {
        display: ["'Sora'", "system-ui", "sans-serif"],
        sans: ["'Inter'", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 2px 20px -4px rgba(10, 15, 40, 0.12)",
        "soft-lg": "0 12px 40px -8px rgba(10, 15, 40, 0.18)",
      },
      keyframes: {
        drift: {
          "0%, 100%": { transform: "translate(0, 0)" },
          "50%": { transform: "translate(2%, -2%)" },
        },
        "fade-in-up": {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        pulseDot: {
          "0%, 80%, 100%": { transform: "scale(0.6)", opacity: "0.4" },
          "40%": { transform: "scale(1)", opacity: "1" },
        },
      },
      animation: {
        drift: "drift 18s ease-in-out infinite",
        "fade-in-up": "fade-in-up 0.35s ease-out",
        "pulse-dot": "pulseDot 1.4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
