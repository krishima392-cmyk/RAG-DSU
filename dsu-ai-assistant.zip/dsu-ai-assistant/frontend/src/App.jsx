import { useCallback, useEffect, useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Footer from "./components/Footer.jsx";
import WelcomeScreen from "./components/WelcomeScreen.jsx";
import ChatWindow from "./components/ChatWindow.jsx";
import ChatInput from "./components/ChatInput.jsx";
import ChatSidebar, { SidebarOpenButton } from "./components/ChatSidebar.jsx";
import { useTheme } from "./hooks/useTheme.js";
import { useConversations } from "./hooks/useConversations.js";
import { sendChatMessage, checkHealth, ApiError } from "./services/api.js";

const SECTION_PROMPTS = {
  programs: "Show me the programs available at DSU.",
  admissions: "Explain the DSU admission process.",
  campus: "What facilities are available on the DSU campus?",
  contact: "How can I contact DSU for admissions enquiries?",
};

export default function App() {
  const { theme, toggleTheme } = useTheme();
  const {
    activeConversation,
    activeId,
    groupedConversations,
    startNewConversation,
    selectConversation,
    deleteConversation,
    addUserMessage,
    addAssistantMessage,
  } = useConversations();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isOnline, setIsOnline] = useState(null); // null = unknown, true/false once checked
  const [lastFailedMessage, setLastFailedMessage] = useState(null);

  useEffect(() => {
    let cancelled = false;
    checkHealth().then((ok) => {
      if (!cancelled) setIsOnline(ok);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const sendMessage = useCallback(
    async (text) => {
      setError(null);
      setLastFailedMessage(null);

      const { conversationId, priorHistory } = addUserMessage(text);
      setIsLoading(true);

      try {
        const reply = await sendChatMessage(text, priorHistory);
        addAssistantMessage(conversationId, reply);
      } catch (err) {
        const message =
          err instanceof ApiError
            ? err.message
            : "Sorry, I couldn't connect to DSU AI right now. Please try again in a moment.";
        setError(message);
        setLastFailedMessage(text);
      } finally {
        setIsLoading(false);
      }
    },
    [addUserMessage, addAssistantMessage]
  );

  const handleRegenerate = useCallback(() => {
    if (!activeConversation) return;
    const messages = activeConversation.messages;
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (lastUser) sendMessage(lastUser.content);
  }, [activeConversation, sendMessage]);

  const handleRetry = useCallback(() => {
    if (lastFailedMessage) sendMessage(lastFailedMessage);
  }, [lastFailedMessage, sendMessage]);

  const handleNewChat = () => {
    if (activeConversation && activeConversation.messages.length > 0) {
      const confirmed = window.confirm("Start a new chat? Your current conversation is saved in history.");
      if (!confirmed) return;
    }
    startNewConversation();
    setSidebarOpen(false);
    setError(null);
  };

  const handleNavSelect = (section) => {
    const prompt = SECTION_PROMPTS[section];
    if (prompt) {
      sendMessage(prompt);
    }
  };

  const handleAboutClick = () => {
    sendMessage("Tell me about Dhanalakshmi Srinivasan University.");
  };

  const messages = activeConversation?.messages ?? [];
  const hasMessages = messages.length > 0;

  return (
    <div className="flex h-screen flex-col bg-slate-50 dark:bg-midnight-950">
      <Navbar
        theme={theme}
        onToggleTheme={toggleTheme}
        onNavSelect={handleNavSelect}
        onAboutClick={handleAboutClick}
      />

      <div className="flex min-h-0 flex-1">
        <ChatSidebar
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen((v) => !v)}
          groupedConversations={groupedConversations}
          activeId={activeId}
          onSelect={(id) => {
            selectConversation(id);
            setSidebarOpen(false);
            setError(null);
          }}
          onDelete={deleteConversation}
          onNewChat={handleNewChat}
        />

        <main className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center justify-between border-b border-slate-200 px-3 py-2 dark:border-white/10 md:px-4">
            <div className="flex items-center gap-2">
              {!sidebarOpen && <SidebarOpenButton onClick={() => setSidebarOpen(true)} />}
              <span className="hidden text-sm font-medium text-midnight-800 dark:text-slate-200 md:inline">
                {activeConversation?.title ?? "New conversation"}
              </span>
            </div>
            {isOnline !== null && (
              <span className="flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500">
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    isOnline ? "bg-emerald-500" : "bg-rose-400"
                  }`}
                />
                {isOnline ? "DSU AI is online" : "Connection issue"}
              </span>
            )}
          </div>

          {hasMessages ? (
            <ChatWindow
              messages={messages}
              isLoading={isLoading}
              error={error}
              onRegenerate={handleRegenerate}
              onRetry={lastFailedMessage ? handleRetry : undefined}
            />
          ) : (
            <WelcomeScreen onSelectPrompt={sendMessage} />
          )}

          <ChatInput onSend={sendMessage} isLoading={isLoading} showSuggestions={!hasMessages} />
        </main>
      </div>

      {!hasMessages && <Footer />}
    </div>
  );
}
