const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

/**
 * Sends a message plus the running conversation to the backend and
 * returns the assistant's reply text.
 *
 * @param {string} message - The new user message.
 * @param {{role: 'user'|'assistant', content: string}[]} conversation - Prior turns (not including `message`).
 * @param {AbortSignal} [signal]
 */
export async function sendChatMessage(message, conversation, signal) {
  let response;
  try {
    response = await fetch(`${API_BASE_URL}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, conversation }),
      signal,
    });
  } catch (err) {
    if (err.name === "AbortError") throw err;
    throw new ApiError(
      "Sorry, I couldn't reach DSU AI Assistant. Please check your connection and try again.",
      0
    );
  }

  let data = null;
  try {
    data = await response.json();
  } catch {
    // non-JSON response body, fall through to generic error below
  }

  if (!response.ok) {
    const detail =
      (data && (data.detail || data.error)) ||
      "Sorry, I couldn't connect to DSU AI right now. Please try again in a moment.";
    throw new ApiError(detail, response.status);
  }

  if (!data || typeof data.reply !== "string") {
    throw new ApiError("Received an unexpected response from the server.", response.status);
  }

  return data.reply;
}

export async function checkHealth(signal) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/health`, { signal });
    if (!response.ok) return false;
    const data = await response.json();
    return data.status === "ok";
  } catch {
    return false;
  }
}
