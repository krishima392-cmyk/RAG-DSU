import { useEffect, useRef, useState } from "react";
import { SendHorizontal } from "lucide-react";

const SUGGESTIONS = [
  "Which courses are available?",
  "What is the admission process?",
  "Where is DSU located?",
  "What facilities are available?",
  "What are the 2026-2027 fees?",
];

export default function ChatInput({ onSend, isLoading, showSuggestions }) {
  const [value, setValue] = useState("");
  const textareaRef = useRef(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  }, [value]);

  const handleSubmit = () => {
    const trimmed = value.trim();
    if (!trimmed || isLoading) return;
    onSend(trimmed);
    setValue("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="border-t border-slate-200 bg-white/95 px-4 pb-4 pt-3 backdrop-blur dark:border-white/10 dark:bg-midnight-950/95 sm:px-6">
      {showSuggestions && (
        <div className="mb-3 flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => onSend(s)}
              className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:border-royal-300 hover:text-royal-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300 dark:hover:border-cyan-400/40 dark:hover:text-cyan-300"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-soft focus-within:border-royal-400 dark:border-white/10 dark:bg-white/[0.04] dark:focus-within:border-cyan-400/60">
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={1}
          placeholder="Ask anything about DSU..."
          aria-label="Message DSU AI Assistant"
          className="max-h-40 flex-1 resize-none bg-transparent px-2 py-2 text-sm text-midnight-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100 dark:placeholder:text-slate-500"
        />
        <button
          type="button"
          onClick={handleSubmit}
          disabled={!value.trim() || isLoading}
          aria-label="Send message"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-royal-600 to-cyan-500 text-white transition disabled:cursor-not-allowed disabled:from-slate-300 disabled:to-slate-300 disabled:text-slate-500 dark:disabled:from-white/10 dark:disabled:to-white/10 dark:disabled:text-slate-500"
        >
          <SendHorizontal className="h-4 w-4" />
        </button>
      </div>
      <p className="mx-auto mt-2 max-w-3xl text-center text-[11px] text-slate-400 dark:text-slate-500">
        DSU AI Assistant answers from the official DSU knowledge base and may be incomplete. Verify
        critical details on dsuniversity.ac.in.
      </p>
    </div>
  );
}
