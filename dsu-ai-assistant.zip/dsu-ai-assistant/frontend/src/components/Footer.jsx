export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white px-4 py-3 text-center dark:border-white/10 dark:bg-midnight-950 sm:px-6">
      <p className="text-xs text-slate-400 dark:text-slate-500">
        Powered by DSU AI &middot; Dhanalakshmi Srinivasan University &middot;{" "}
        <a
          href="https://www.dsuniversity.ac.in/"
          target="_blank"
          rel="noreferrer"
          className="underline decoration-slate-300 underline-offset-2 hover:text-royal-600 dark:hover:text-cyan-300"
        >
          dsuniversity.ac.in
        </a>
      </p>
    </footer>
  );
}
