import { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Check, Copy, GraduationCap, RotateCcw, ThumbsDown, ThumbsUp, User } from "lucide-react";

export default function ChatMessage({ message, onRegenerate, isLast }) {
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState(null); // 'up' | 'down' | null

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // clipboard may be unavailable - fail silently, non-critical action
    }
  };

  if (isUser) {
    return (
      <div className="flex justify-end px-1">
        <div className="flex max-w-[85%] items-start gap-3 sm:max-w-[75%]">
          <div className="animate-fade-in-up rounded-2xl rounded-tr-sm bg-gradient-to-br from-royal-600 to-royal-700 px-4 py-2.5 text-sm text-white shadow-soft">
            {message.content}
          </div>
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-200 text-slate-600 dark:bg-white/10 dark:text-slate-300">
            <User className="h-4 w-4" />
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start px-1">
      <div className="flex max-w-[92%] items-start gap-3 sm:max-w-[80%]">
        <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-royal-600 to-cyan-500 text-white">
          <GraduationCap className="h-4 w-4" />
        </span>
        <div className="animate-fade-in-up flex flex-col gap-1.5">
          <div className="dsu-prose rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-4 py-3 text-slate-800 shadow-soft dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-100">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{message.content}</ReactMarkdown>
          </div>

          <div className="flex items-center gap-1 pl-1 text-slate-400 dark:text-slate-500">
            <button
              type="button"
              onClick={handleCopy}
              aria-label="Copy response"
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg transition hover:bg-slate-100 hover:text-midnight-700 dark:hover:bg-white/5 dark:hover:text-slate-200"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
            </button>

            {isLast && onRegenerate && (
              <button
                type="button"
                onClick={onRegenerate}
                aria-label="Regenerate response"
                className="inline-flex h-7 w-7 items-center justify-center rounded-lg transition hover:bg-slate-100 hover:text-midnight-700 dark:hover:bg-white/5 dark:hover:text-slate-200"
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setFeedback((f) => (f === "up" ? null : "up"))}
              aria-label="Helpful"
              aria-pressed={feedback === "up"}
              className={`inline-flex h-7 w-7 items-center justify-center rounded-lg transition hover:bg-slate-100 dark:hover:bg-white/5 ${
                feedback === "up" ? "text-emerald-500" : "hover:text-midnight-700 dark:hover:text-slate-200"
              }`}
            >
              <ThumbsUp className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setFeedback((f) => (f === "down" ? null : "down"))}
              aria-label="Not helpful"
              aria-pressed={feedback === "down"}
              className={`inline-flex h-7 w-7 items-center justify-center rounded-lg transition hover:bg-slate-100 dark:hover:bg-white/5 ${
                feedback === "down" ? "text-rose-500" : "hover:text-midnight-700 dark:hover:text-slate-200"
              }`}
            >
              <ThumbsDown className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
