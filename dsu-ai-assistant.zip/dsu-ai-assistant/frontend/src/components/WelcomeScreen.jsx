import { Sparkles } from "lucide-react";
import QuickActions from "./QuickActions.jsx";

export default function WelcomeScreen({ onSelectPrompt }) {
  return (
    <div className="relative flex flex-1 flex-col items-center overflow-hidden px-4 py-10 sm:py-14">
      {/* Subtle animated background - a quiet network of nodes suggesting knowledge/connection */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute left-1/2 top-0 h-[560px] w-[900px] -translate-x-1/2 animate-drift rounded-full bg-gradient-to-br from-royal-200/40 via-cyan-100/30 to-transparent blur-3xl dark:from-royal-800/25 dark:via-cyan-500/10" />
        <svg
          className="absolute inset-0 h-full w-full opacity-[0.35] dark:opacity-[0.18]"
          viewBox="0 0 800 400"
          fill="none"
        >
          <g stroke="currentColor" className="text-royal-300 dark:text-cyan-400" strokeWidth="1">
            <line x1="60" y1="60" x2="220" y2="140" />
            <line x1="220" y1="140" x2="420" y2="80" />
            <line x1="420" y1="80" x2="620" y2="160" />
            <line x1="220" y1="140" x2="300" y2="260" />
            <line x1="300" y1="260" x2="520" y2="300" />
            <line x1="520" y1="300" x2="700" y2="220" />
            <line x1="420" y1="80" x2="560" y2="30" />
          </g>
          <g fill="currentColor" className="text-royal-400 dark:text-cyan-300">
            <circle cx="60" cy="60" r="3.5" />
            <circle cx="220" cy="140" r="4" />
            <circle cx="420" cy="80" r="3.5" />
            <circle cx="620" cy="160" r="3.5" />
            <circle cx="300" cy="260" r="4" />
            <circle cx="520" cy="300" r="3.5" />
            <circle cx="700" cy="220" r="3.5" />
            <circle cx="560" cy="30" r="3" />
          </g>
        </svg>
      </div>

      <div className="mx-auto flex w-full max-w-3xl flex-col items-center text-center">
        <span className="mb-5 inline-flex items-center gap-1.5 rounded-full border border-royal-200 bg-white/70 px-3.5 py-1.5 text-xs font-medium text-royal-700 shadow-soft dark:border-cyan-400/30 dark:bg-white/5 dark:text-cyan-300">
          <Sparkles className="h-3.5 w-3.5" />
          Powered by DSU AI
        </span>

        <h1 className="font-display text-3xl font-bold tracking-tight text-midnight-900 dark:text-white sm:text-4xl">
          Welcome to DSU AI Assistant
        </h1>
        <p className="mt-3 max-w-xl text-base text-slate-600 dark:text-slate-300 sm:text-lg">
          How can I help you explore Dhanalakshmi Srinivasan University?
        </p>
        <p className="mt-2 max-w-lg text-sm text-slate-500 dark:text-slate-400">
          Get instant answers about programs, admissions, fees, campus facilities, hostel, and
          more.
        </p>
      </div>

      <div className="mt-10 w-full max-w-3xl">
        <QuickActions onSelect={onSelectPrompt} />
      </div>
    </div>
  );
}
