import { GraduationCap } from "lucide-react";

export default function TypingIndicator() {
  return (
    <div className="flex items-start gap-3 px-1">
      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-royal-600 to-cyan-500 text-white">
        <GraduationCap className="h-4 w-4" />
      </span>
      <div className="flex items-center gap-2 rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-4 py-3 text-sm text-slate-500 shadow-soft dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">
        <span>DSU AI is thinking</span>
        <span className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-royal-400 dark:bg-cyan-400 [animation-delay:0ms]" />
          <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-royal-400 dark:bg-cyan-400 [animation-delay:150ms]" />
          <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-royal-400 dark:bg-cyan-400 [animation-delay:300ms]" />
        </span>
      </div>
    </div>
  );
}
