import {
  GraduationCap,
  Wallet,
  ClipboardList,
  Building2,
  Home,
  MapPin,
  Phone,
} from "lucide-react";

export const QUICK_ACTIONS = [
  {
    icon: GraduationCap,
    label: "Explore Programs",
    prompt: "What courses are available at DSU?",
  },
  {
    icon: Wallet,
    label: "Fee Structure",
    prompt: "What is the 2026-2027 fee structure?",
  },
  {
    icon: ClipboardList,
    label: "Admission Process",
    prompt: "Explain the DSU admission process.",
  },
  {
    icon: Building2,
    label: "Campus & Facilities",
    prompt: "What facilities are available on the DSU campus?",
  },
  {
    icon: Home,
    label: "Hostel Information",
    prompt: "Tell me about hostel facilities at DSU.",
  },
  {
    icon: MapPin,
    label: "Campus Location",
    prompt: "Where is DSU located?",
  },
  {
    icon: Phone,
    label: "Contact DSU",
    prompt: "How can I contact DSU for admissions enquiries?",
  },
];

export default function QuickActions({ onSelect }) {
  return (
    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
      {QUICK_ACTIONS.map(({ icon: Icon, label, prompt }) => (
        <button
          key={label}
          type="button"
          onClick={() => onSelect(prompt)}
          className="group flex flex-col items-start gap-2.5 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-soft transition hover:-translate-y-0.5 hover:border-royal-300 hover:shadow-soft-lg dark:border-white/10 dark:bg-white/[0.04] dark:hover:border-cyan-400/40"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-royal-50 text-royal-700 transition group-hover:bg-royal-600 group-hover:text-white dark:bg-cyan-400/10 dark:text-cyan-300 dark:group-hover:bg-cyan-400 dark:group-hover:text-midnight-950">
            <Icon className="h-4.5 w-4.5" strokeWidth={2} />
          </span>
          <span className="text-sm font-medium leading-snug text-midnight-800 dark:text-slate-100">
            {label}
          </span>
        </button>
      ))}
    </div>
  );
}
