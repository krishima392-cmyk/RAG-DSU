import { MessageSquare, PanelLeftClose, PanelLeftOpen, Plus, Trash2 } from "lucide-react";

function ConversationGroup({ label, items, activeId, onSelect, onDelete }) {
  if (!items.length) return null;
  return (
    <div className="mb-4">
      <p className="mb-1.5 px-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">
        {label}
      </p>
      <div className="flex flex-col gap-0.5">
        {items.map((c) => (
          <div
            key={c.id}
            className={`group flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition ${
              c.id === activeId
                ? "bg-royal-50 text-royal-800 dark:bg-cyan-400/10 dark:text-cyan-200"
                : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5"
            }`}
          >
            <button
              type="button"
              onClick={() => onSelect(c.id)}
              className="flex flex-1 items-center gap-2 overflow-hidden text-left"
            >
              <MessageSquare className="h-3.5 w-3.5 shrink-0 opacity-70" />
              <span className="truncate">{c.title}</span>
            </button>
            <button
              type="button"
              onClick={() => onDelete(c.id)}
              aria-label={`Delete conversation: ${c.title}`}
              className="hidden h-6 w-6 shrink-0 items-center justify-center rounded-md text-slate-400 hover:bg-slate-200 hover:text-rose-600 group-hover:flex dark:hover:bg-white/10 dark:hover:text-rose-400"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ChatSidebar({
  isOpen,
  onToggle,
  groupedConversations,
  activeId,
  onSelect,
  onDelete,
  onNewChat,
}) {
  return (
    <>
      {isOpen && (
        <button
          type="button"
          aria-label="Close sidebar"
          onClick={onToggle}
          className="fixed inset-0 z-30 bg-midnight-950/40 backdrop-blur-sm md:hidden"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 shrink-0 flex-col border-r border-slate-200 bg-white transition-transform duration-200 dark:border-white/10 dark:bg-midnight-950 md:static md:z-auto md:translate-x-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } ${isOpen ? "" : "md:w-0 md:border-r-0 md:overflow-hidden"}`}
      >
        <div className="flex items-center justify-between gap-2 border-b border-slate-200 p-3 dark:border-white/10">
          <button
            type="button"
            onClick={onNewChat}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-royal-600 to-royal-700 px-3 py-2 text-sm font-medium text-white shadow-soft transition hover:opacity-95"
          >
            <Plus className="h-4 w-4" />
            New Chat
          </button>
          <button
            type="button"
            onClick={onToggle}
            aria-label="Collapse sidebar"
            className="hidden h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-midnight-700 dark:hover:bg-white/5 dark:hover:text-slate-200 md:flex"
          >
            <PanelLeftClose className="h-4 w-4" />
          </button>
        </div>

        <div className="thin-scrollbar flex-1 overflow-y-auto p-2">
          {Object.values(groupedConversations).every((g) => g.length === 0) ? (
            <p className="px-2 py-6 text-center text-xs text-slate-400 dark:text-slate-500">
              No conversations yet. Start by asking a question!
            </p>
          ) : (
            Object.entries(groupedConversations).map(([label, items]) => (
              <ConversationGroup
                key={label}
                label={label}
                items={items}
                activeId={activeId}
                onSelect={onSelect}
                onDelete={onDelete}
              />
            ))
          )}
        </div>
      </aside>
    </>
  );
}

export function SidebarOpenButton({ onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="Open sidebar"
      className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-midnight-700 dark:text-slate-300 dark:hover:bg-white/5 dark:hover:text-white"
    >
      <PanelLeftOpen className="h-4 w-4" />
    </button>
  );
}
