import { useEffect, useRef, useState } from "react";
import { ArrowDown, AlertTriangle } from "lucide-react";
import ChatMessage from "./ChatMessage.jsx";
import TypingIndicator from "./TypingIndicator.jsx";

export default function ChatWindow({ messages, isLoading, error, onRegenerate, onRetry }) {
  const scrollRef = useRef(null);
  const bottomRef = useRef(null);
  const [showScrollButton, setShowScrollButton] = useState(false);

  const scrollToBottom = (behavior = "smooth") => {
    bottomRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages.length, isLoading]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollButton(distanceFromBottom > 200);
  };

  const lastAssistantIndex = [...messages].reverse().findIndex((m) => m.role === "assistant");
  const lastAssistantId =
    lastAssistantIndex >= 0 ? messages[messages.length - 1 - lastAssistantIndex].id : null;

  return (
    <div className="relative flex flex-1 flex-col overflow-hidden">
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="thin-scrollbar flex-1 space-y-5 overflow-y-auto px-3 py-6 sm:px-6"
      >
        <div className="mx-auto flex max-w-3xl flex-col gap-5">
          {messages.map((message) => (
            <ChatMessage
              key={message.id}
              message={message}
              isLast={message.id === lastAssistantId}
              onRegenerate={message.id === lastAssistantId ? onRegenerate : undefined}
            />
          ))}

          {isLoading && <TypingIndicator />}

          {error && (
            <div className="flex items-start justify-between gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
              {onRetry && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="shrink-0 rounded-lg border border-rose-300 px-2.5 py-1 text-xs font-medium hover:bg-rose-100 dark:border-rose-500/40 dark:hover:bg-rose-500/10"
                >
                  Retry
                </button>
              )}
            </div>
          )}

          <div ref={bottomRef} />
        </div>
      </div>

      {showScrollButton && (
        <button
          type="button"
          onClick={() => scrollToBottom()}
          aria-label="Scroll to latest message"
          className="absolute bottom-4 left-1/2 flex h-9 w-9 -translate-x-1/2 items-center justify-center rounded-full border border-slate-200 bg-white text-midnight-700 shadow-soft-lg transition hover:-translate-y-0.5 dark:border-white/10 dark:bg-midnight-900 dark:text-slate-200"
        >
          <ArrowDown className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
