import { useState } from "react";
import { GraduationCap, Menu, X } from "lucide-react";
import ThemeToggle from "./ThemeToggle.jsx";

const NAV_LINKS = [
  { label: "Home", section: "home" },
  { label: "Programs", section: "programs" },
  { label: "Admissions", section: "admissions" },
  { label: "Campus", section: "campus" },
  { label: "Contact", section: "contact" },
];

export default function Navbar({ theme, onToggleTheme, onNavSelect, onAboutClick }) {
  const [open, setOpen] = useState(false);

  const handleSelect = (section) => {
    setOpen(false);
    onNavSelect(section);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/85 backdrop-blur dark:border-white/10 dark:bg-midnight-950/85">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <button
          type="button"
          onClick={() => handleSelect("home")}
          className="flex items-center gap-2.5"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-royal-600 to-cyan-500 text-white shadow-soft">
            <GraduationCap className="h-5 w-5" strokeWidth={2.25} />
          </span>
          <span className="font-display text-[15px] font-semibold tracking-tight text-midnight-900 dark:text-white">
            DSU AI Assistant
          </span>
        </button>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => (
            <button
              key={link.section}
              type="button"
              onClick={() => handleSelect(link.section)}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-midnight-900 dark:text-slate-300 dark:hover:bg-white/5 dark:hover:text-white"
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
          <button
            type="button"
            onClick={onAboutClick}
            className="rounded-lg border border-slate-200 px-3.5 py-2 text-sm font-medium text-midnight-800 transition hover:border-royal-300 hover:text-royal-700 dark:border-white/10 dark:text-slate-200 dark:hover:border-cyan-400/40 dark:hover:text-cyan-300"
          >
            About
          </button>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-midnight-700 dark:border-white/10 dark:text-slate-200"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-slate-200 bg-white px-4 py-3 dark:border-white/10 dark:bg-midnight-950 md:hidden">
          <div className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <button
                key={link.section}
                type="button"
                onClick={() => handleSelect(link.section)}
                className="rounded-lg px-3 py-2.5 text-left text-sm font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/5"
              >
                {link.label}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onAboutClick();
              }}
              className="rounded-lg px-3 py-2.5 text-left text-sm font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/5"
            >
              About
            </button>
          </div>
        </nav>
      )}
    </header>
  );
}
