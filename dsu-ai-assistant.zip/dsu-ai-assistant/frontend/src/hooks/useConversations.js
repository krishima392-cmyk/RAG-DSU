import { useCallback, useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "dsu-ai-conversations";

function loadFromStorage() {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveToStorage(conversations) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
  } catch {
    // localStorage may be unavailable (private mode, quota) - fail silently,
    // the chat still works for the current session.
  }
}

function makeId() {
  return `conv_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function titleFromMessage(text) {
  const trimmed = text.trim().replace(/\s+/g, " ");
  return trimmed.length > 42 ? `${trimmed.slice(0, 42)}...` : trimmed || "New conversation";
}

/**
 * Manages the list of conversations, the active conversation, and
 * localStorage persistence. Every conversation has the shape:
 *   { id, title, messages: [{role, content, id}], createdAt, updatedAt }
 *
 * NOTE: this is intentionally structured so a future database-backed
 * implementation (e.g. persisting to the FastAPI backend per user account)
 * only needs to swap the storage functions below - the component API
 * (conversations, activeConversation, actions) stays the same.
 */
export function useConversations() {
  const [conversations, setConversations] = useState(loadFromStorage);
  const [activeId, setActiveId] = useState(null);

  useEffect(() => {
    saveToStorage(conversations);
  }, [conversations]);

  const activeConversation = useMemo(
    () => conversations.find((c) => c.id === activeId) || null,
    [conversations, activeId]
  );

  const startNewConversation = useCallback(() => {
    setActiveId(null); // null activeId = show WelcomeScreen; conversation is created on first message
  }, []);

  const selectConversation = useCallback((id) => {
    setActiveId(id);
  }, []);

  const deleteConversation = useCallback(
    (id) => {
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeId === id) setActiveId(null);
    },
    [activeId]
  );

  /**
   * Ensures there's an active conversation, adds the user message to it,
   * and returns { conversationId, history } where `history` is the prior
   * turns (before this message) for sending to the API.
   */
  const addUserMessage = useCallback(
    (content) => {
      let conversationId = activeId;
      let priorHistory = [];

      setConversations((prev) => {
        let next = prev;
        if (!conversationId) {
          conversationId = makeId();
          const newConv = {
            id: conversationId,
            title: titleFromMessage(content),
            messages: [],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          next = [newConv, ...prev];
        }

        return next.map((c) => {
          if (c.id !== conversationId) return c;
          priorHistory = c.messages.map((m) => ({ role: m.role, content: m.content }));
          return {
            ...c,
            messages: [...c.messages, { id: makeId(), role: "user", content }],
            updatedAt: Date.now(),
          };
        });
      });

      setActiveId(conversationId);
      return { conversationId, priorHistory };
    },
    [activeId]
  );

  const addAssistantMessage = useCallback((conversationId, content) => {
    setConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              messages: [...c.messages, { id: makeId(), role: "assistant", content }],
              updatedAt: Date.now(),
            }
          : c
      )
    );
  }, []);

  const groupedConversations = useMemo(() => {
    const sorted = [...conversations].sort((a, b) => b.updatedAt - a.updatedAt);
    const now = new Date();
    const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const today = startOfDay(now);
    const yesterday = today - 86400000;

    const groups = { Today: [], Yesterday: [], Previous: [] };
    for (const c of sorted) {
      if (c.updatedAt >= today) groups.Today.push(c);
      else if (c.updatedAt >= yesterday) groups.Yesterday.push(c);
      else groups.Previous.push(c);
    }
    return groups;
  }, [conversations]);

  return {
    conversations,
    groupedConversations,
    activeConversation,
    activeId,
    startNewConversation,
    selectConversation,
    deleteConversation,
    addUserMessage,
    addAssistantMessage,
  };
}
