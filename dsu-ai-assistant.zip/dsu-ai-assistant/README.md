# DSU AI Assistant

**Your intelligent guide to Dhanalakshmi Srinivasan University**

A production-quality chatbot website for DSU, built on top of your existing Gemini
chatbot logic and knowledge base. React/Vite/Tailwind frontend, FastAPI backend.

---

## ⚠️ Before anything else: rotate your API key

Your original notebook (`chat.ipynb`) has a Gemini API key hardcoded directly in the
code (`genai.Client(api_key="AQ.Ab8...")`). That key is now sitting in a plaintext file.
**Revoke/rotate it in [Google AI Studio](https://aistudio.google.com/apikey) and generate
a fresh key** before using this project — never reuse a key that's already been exposed
in a shared or uploaded file. This project never puts the key in code; it always reads it
from an environment variable that isn't committed to source control.

---

## 1. What this preserves from your notebook

| Notebook piece | Where it lives now | What changed |
|---|---|---|
| `genai.Client(api_key=...)` | `backend/chatbot.py` | Key now comes from `GEMINI_API_KEY` env var, never hardcoded |
| Knowledge base loading (`open(...).read()`) | `backend/knowledge_base.py` | Same read, wrapped in a cached function |
| System prompt text | `backend/prompts.py` | Identical grounding rules, moved into its own module |
| `"models/gemini-3.1-flash-lite"` | `backend/chatbot.py` (`DEFAULT_MODEL`) | Same model, overridable via `GEMINI_MODEL` env var |
| `chat.send_message(...)` (stateful chat object) | `backend/chatbot.py` (`generate_reply`) | Swapped for `generate_content` with the full conversation history sent on every call — necessary because a REST API is stateless between requests (there's no single Python process holding one `chat` object per browser tab). Produces the same multi-turn behavior. |

Nothing about *how* the model is grounded in the DSU knowledge base, or the rules it
follows, was changed — only the plumbing needed to serve it over HTTP to a real website.

---

## 2. Architecture

```
User
 ↓
React UI  (frontend/)
 ↓  POST /api/chat  { message, conversation }
FastAPI   (backend/main.py)
 ↓
chatbot.py  →  prompts.py + knowledge_base.py  (DSU knowledge base)
 ↓
Gemini API
 ↓
FastAPI   →  { reply, success }
 ↓
React UI  →  Markdown-rendered chat bubble
```

---

## 3. Folder structure

```
dsu-ai-assistant/
├── backend/
│   ├── main.py                       # FastAPI app: /api/chat, /api/health
│   ├── chatbot.py                    # Gemini call (preserves original model/config)
│   ├── knowledge_base.py             # Loads the DSU knowledge-base text
│   ├── prompts.py                    # System prompt (same rules as the notebook)
│   ├── dsu_chatbot_knowledge_base.txt
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/               # Navbar, WelcomeScreen, QuickActions, ChatWindow,
│   │   │                              # ChatMessage, ChatInput, ChatSidebar, TypingIndicator,
│   │   │                              # ThemeToggle, Footer
│   │   ├── hooks/                    # useTheme, useConversations (localStorage history)
│   │   ├── services/                 # api.js (talks to the backend)
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── tailwind.config.js
│   ├── vite.config.js
│   ├── package.json
│   └── .env.example
├── .gitignore
└── README.md
```

---

## 4. Features

- Premium, DSU-branded UI (deep navy / royal blue / cyan palette, "Sora" display +
  "Inter" body type) — desktop and mobile responsive, light and dark mode.
- Hero welcome screen with quick-action cards (Programs, Fees, Admissions, Campus,
  Hostel, Location, Contact) that fire a pre-written question straight into the chat.
- Full chat experience: markdown rendering (headings, lists, bold, links, tables),
  copy/regenerate/feedback buttons, auto-growing input, Enter-to-send /
  Shift+Enter-for-newline, scroll-to-bottom button, typing indicator.
- Collapsible sidebar with chat history grouped by Today / Yesterday / Previous,
  stored in `localStorage` (swap the storage functions in `useConversations.js` for a
  real database later — the rest of the app doesn't need to change).
- Friendly, non-technical error states for backend/API/network failures — no stack
  traces or keys ever reach the browser.
- Answers are grounded strictly in `dsu_chatbot_knowledge_base.txt`; the assistant is
  instructed to say so plainly when something isn't in the knowledge base rather than
  guessing.

---

## 5. Running it locally

### Backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and paste your (new, rotated) GEMINI_API_KEY

uvicorn main:app --reload --port 8000
```

Check it's alive: `curl http://localhost:8000/api/health` → `{"status":"ok"}`

### Frontend

```bash
cd frontend
npm install

cp .env.example .env
# VITE_API_URL=http://localhost:8000  (already the default)

npm run dev
```

Open the printed local URL (typically `http://localhost:5173`).

---

## 6. Updating the knowledge base

Edit `backend/dsu_chatbot_knowledge_base.txt` directly (it's the same file your notebook
used). No code changes needed — `knowledge_base.py` re-reads it on process restart. If you
want hot-reload without restarting, call `load_knowledge_base.cache_clear()` from a
maintenance endpoint before the next request.

Keep following the file's own rule: **never add fees, courses, placement stats, or
contact info you haven't verified from an official DSU source.**

---

## 7. Deployment notes

- **Backend**: any ASGI host works (Render, Railway, Fly.io, a VM behind nginx, etc).
  Set `GEMINI_API_KEY` and `ALLOWED_ORIGINS` (comma-separated list of your deployed
  frontend origin(s)) as environment variables on the host — don't ship a `.env` file.
- **Frontend**: `npm run build` produces a static `dist/` folder deployable to Vercel,
  Netlify, Cloudflare Pages, or any static host. Set `VITE_API_URL` to your deployed
  backend URL at build time.
- Make sure CORS (`ALLOWED_ORIGINS` in `backend/main.py`) includes your real frontend
  domain once deployed, or the browser will block requests.

---

## 8. Common errors and fixes

| Symptom | Likely cause | Fix |
|---|---|---|
| Frontend shows "Sorry, I couldn't connect to DSU AI right now" | Backend isn't running, or `VITE_API_URL` is wrong | Confirm `uvicorn` is running and reachable at the URL in `frontend/.env` |
| Backend returns 500 with "not configured correctly" | `GEMINI_API_KEY` missing in `backend/.env` | Copy `.env.example` → `.env` and add a valid key |
| CORS error in the browser console | Frontend origin not in `ALLOWED_ORIGINS` | Add it (comma-separated) in `backend/.env` |
| `ModuleNotFoundError: google.genai` | Dependencies not installed in the active venv | `pip install -r requirements.txt` inside the activated virtual environment |
| Chat history disappears | Browser cleared `localStorage`, or private/incognito mode | Expected with the current localStorage-only storage; move to a database-backed store for persistence across devices |
| Gemini returns odd/empty answers | Model name changed or deprecated | Check `client.models.list()` output (as you did in the notebook) and update `GEMINI_MODEL` in `backend/.env` |

---

## 9. What's intentionally left as a "next step"

To keep this a working, reviewable v1 rather than an over-scoped rewrite:

- Chat history is `localStorage`-only (no accounts/database yet) — the hook is shaped
  so swapping in a real backend-persisted store later is a small, contained change.
- Feedback (thumbs up/down) is captured in the UI but not yet sent anywhere — wire it
  to a logging endpoint when you're ready to collect it.
- No authentication layer — add one at the FastAPI level if you need to restrict access.
