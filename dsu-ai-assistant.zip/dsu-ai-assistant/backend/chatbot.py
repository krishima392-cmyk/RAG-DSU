"""
chatbot.py

Wraps the Gemini call. This preserves the same provider, SDK, and model
configuration approach used in the original notebook:

    from google import genai
    client = genai.Client(api_key=...)
    chat = client.chats.create(model="models/gemini-3.1-flash-lite",
                                config={'system_instruction': prompt})
    response = chat.send_message(user_text)

The one architectural change is that a REST API is stateless between
requests (there's no single long-lived Python process holding a `chat`
object per browser tab), so instead of `client.chats.create(...)` +
`chat.send_message(...)` we use `client.models.generate_content(...)`
and pass the *entire* conversation history with every call. The frontend
keeps the conversation and sends it back each time - same idea used for
any stateless chat API. Functionally this produces the same multi-turn
behaviour as the notebook's `chat` object.

Never hardcode the API key. It is read from the GEMINI_API_KEY
environment variable (see .env.example).
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Iterable, List, Literal

from google import genai
from google.genai import types

from knowledge_base import load_knowledge_base
from prompts import build_system_prompt

# Same model already used and verified working in the original notebook.
# Override with GEMINI_MODEL in .env if you want to point at a different
# model from the `client.models.list()` output you already captured.
DEFAULT_MODEL = "models/gemini-3.1-flash-lite"


class ChatbotConfigError(RuntimeError):
    """Raised when the chatbot cannot be initialized (e.g. missing API key)."""


class ChatbotUpstreamError(RuntimeError):
    """Raised when the Gemini API call itself fails (network, quota, etc)."""


@dataclass
class TurnMessage:
    role: Literal["user", "assistant"]
    content: str


def _get_client() -> genai.Client:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise ChatbotConfigError(
            "GEMINI_API_KEY is not set. Copy backend/.env.example to backend/.env "
            "and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def _get_model_name() -> str:
    return os.environ.get("GEMINI_MODEL", DEFAULT_MODEL)


def _to_gemini_contents(history: Iterable[TurnMessage]) -> List[types.Content]:
    """
    Converts our {role: 'user'|'assistant', content} turns into Gemini's
    expected Content objects. Gemini uses 'model' (not 'assistant') for
    the AI's turns.
    """
    contents: List[types.Content] = []
    for turn in history:
        gemini_role = "model" if turn.role == "assistant" else "user"
        contents.append(
            types.Content(role=gemini_role, parts=[types.Part(text=turn.content)])
        )
    return contents


def generate_reply(message: str, conversation: List[TurnMessage]) -> str:
    """
    Sends `message` (plus prior `conversation` turns for context) to Gemini,
    grounded in the DSU knowledge base via the system instruction, and
    returns the reply text.

    Raises ChatbotConfigError / ChatbotUpstreamError on failure so the API
    layer can turn those into clean, user-safe error responses.
    """
    if not message or not message.strip():
        raise ValueError("message must not be empty")

    client = _get_client()
    model_name = _get_model_name()

    kb = load_knowledge_base()
    system_instruction = build_system_prompt(kb)

    contents = _to_gemini_contents(conversation)
    contents.append(types.Content(role="user", parts=[types.Part(text=message)]))

    try:
        response = client.models.generate_content(
            model=model_name,
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
            ),
        )
    except Exception as exc:  # noqa: BLE001 - deliberately broad, re-raised as our own type
        raise ChatbotUpstreamError(str(exc)) from exc

    text = getattr(response, "text", None)
    if not text:
        raise ChatbotUpstreamError("Gemini returned an empty response.")

    return text
