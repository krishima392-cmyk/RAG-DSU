"""
knowledge_base.py

Loads the DSU knowledge-base text file that acts as the chatbot's single
source of truth for university-specific facts (programmes, fees, campus,
admissions, contacts, etc).

This preserves the exact loading approach from the original notebook:

    with open("dsu_chatbot_knowledge_base.txt", "r", encoding="utf-8") as f:
        kb = f.read()

...just wrapped in a reusable, cached function so the file is read once
per process instead of on every request.
"""

from __future__ import annotations

import functools
from pathlib import Path

# The knowledge base file lives next to this module by default.
KB_PATH = Path(__file__).parent / "dsu_chatbot_knowledge_base.txt"


@functools.lru_cache(maxsize=1)
def load_knowledge_base(path: Path = KB_PATH) -> str:
    """
    Reads and returns the DSU knowledge-base text.

    Cached so repeated calls (e.g. once per incoming chat request) don't
    re-read the file from disk. Call load_knowledge_base.cache_clear()
    if you ever need to hot-reload the file without restarting the server.
    """
    if not path.exists():
        raise FileNotFoundError(
            f"DSU knowledge base not found at {path}. "
            "Make sure dsu_chatbot_knowledge_base.txt sits next to knowledge_base.py, "
            "or pass an explicit path."
        )

    with open(path, "r", encoding="utf-8") as f:
        return f.read()
