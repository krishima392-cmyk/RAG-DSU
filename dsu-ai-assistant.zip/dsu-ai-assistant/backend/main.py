"""
main.py

FastAPI application exposing the DSU chatbot over HTTP so the React
frontend can talk to it.

Endpoints:
    POST /api/chat    -> { message, conversation } -> { reply, success }
    GET  /api/health   -> { status }

Run locally with:
    uvicorn main:app --reload --port 8000
"""

from __future__ import annotations

import logging
import os
from typing import List, Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from chatbot import ChatbotConfigError, ChatbotUpstreamError, TurnMessage, generate_reply

load_dotenv()  # reads backend/.env if present

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("dsu-ai-assistant")

app = FastAPI(title="DSU AI Assistant API", version="1.0.0")

# Comma-separated list of allowed origins, e.g. "http://localhost:5173,https://dsuassistant.app"
_allowed_origins = os.environ.get("ALLOWED_ORIGINS", "http://localhost:5173").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in _allowed_origins if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ConversationTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000)
    conversation: List[ConversationTurn] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str
    success: bool = True


class HealthResponse(BaseModel):
    status: str


@app.get("/api/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest) -> ChatResponse:
    message = request.message.strip()
    if not message:
        raise HTTPException(status_code=400, detail="Message must not be empty.")

    history = [TurnMessage(role=t.role, content=t.content) for t in request.conversation]

    try:
        reply_text = generate_reply(message, history)
    except ChatbotConfigError as exc:
        logger.error("Chatbot configuration error: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="DSU AI Assistant is not configured correctly. Please contact the site administrator.",
        ) from exc
    except ChatbotUpstreamError as exc:
        logger.error("Gemini upstream error: %s", exc)
        raise HTTPException(
            status_code=502,
            detail="Sorry, I couldn't connect to DSU AI right now. Please try again in a moment.",
        ) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - final safety net, never leak internals
        logger.exception("Unexpected error while generating reply")
        raise HTTPException(
            status_code=500,
            detail="Something went wrong on our end. Please try again shortly.",
        ) from exc

    return ChatResponse(reply=reply_text, success=True)
